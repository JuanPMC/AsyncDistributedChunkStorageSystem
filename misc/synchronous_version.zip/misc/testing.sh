# test 1 node
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 300 &
wait
mv log.txt log-1Node.txt

# test 4 nodes
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 75 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 75 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 75 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 75 &
wait
mv log.txt log-4Node.txt

# test 8 nodes
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 38 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 38 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 38 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 38 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 37 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 37 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 37 &
go run testing_binary.go -file shared_dir/pepeNites.txt -host 127.0.0.1 -port 9000 -repeat 37 &
wait
mv log.txt log-8Node.txt
