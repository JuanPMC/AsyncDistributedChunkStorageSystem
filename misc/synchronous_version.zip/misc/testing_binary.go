package main

import (
	"crypto/md5"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"time"
)

// Function for querying a file from the server
func queryFileFromServer(host string, port int, filename string) ([]byte, error) {
	// Construct the command to query the file
	command := "query 0 0 10 " + filename

	// Send the command to the server and retrieve the response
	response, _, err := sendCommand(host, port, command)
	if err != nil {
		return nil, err
	}

	return response, nil
}

// Function for sending commands to the server
func sendCommand(host string, port int, command string) ([]byte, string, error) {
	// Establish a TCP connection to the server
	conn, err := net.Dial("tcp", fmt.Sprintf("%s:%d", host, port))
	if err != nil {
		return nil, "", err
	}
	defer conn.Close()

	// Write the command to the server
	_, err = conn.Write([]byte(command))
	if err != nil {
		return nil, "", err
	}

	// Read the response from the server
	var response []byte
	md5Hash := md5.New()
	buffer := make([]byte, 1024)
	for {
		n, err := conn.Read(buffer)
		if err != nil && err != io.EOF {
			return nil, "", err
		}
		if n == 0 {
			break
		}
		response = append(response, buffer[:n]...)
		md5Hash.Write(buffer[:n])
	}

	md5Hex := fmt.Sprintf("%x", md5Hash.Sum(nil))
	return response, md5Hex, nil
}

func main() {
	// Parse command-line arguments
	var (
		host     string
		port     int
		filename string
		repeat   int
	)
	flag.StringVar(&host, "host", "localhost", "Server hostname or IP address")
	flag.IntVar(&port, "port", 8080, "Server port")
	flag.StringVar(&filename, "file", "", "File to query from the server")
	flag.IntVar(&repeat, "repeat", 1, "Number of times to repeat the experiment")
	flag.Parse()

	// Check if a filename is provided
	if filename == "" {
		fmt.Println("Usage: go run main.go -file <filename> [-host <hostname>] [-port <port>] [-repeat <n>]")
		os.Exit(1)
	}

	// Open or create the log file
	logFile := "log.txt"
	logFilePtr, err := os.OpenFile(logFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Fatal("Error opening log file:", err)
	}
	defer logFilePtr.Close()

	// Set the log output to the log file
	log.SetOutput(logFilePtr)

	// Repeat the experiment 'repeat' times
	for i := 0; i < repeat; i++ {
		// Start the timer
		start := time.Now()

		// Query the file from the server
		response, err := queryFileFromServer(host, port, filename)
		if err != nil {
			log.Fatal("Error querying file:", err)
		}
		elapsed := time.Since(start)

		// Print the response
		fmt.Println("Response from server:", string(response))

		// Log the elapsed time to the log file
		log.Printf("Experiment %d - Query time for file %s: %s\n", i+1, filename, elapsed)
	}
}
